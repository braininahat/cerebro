# ##########################################################################
# # SignalJEPA Submission for NeurIPS 2025 EEG Challenge
# # --------------------------------------------------------
# The zip file needs to be single level depth!
# NO FOLDER
# submission_signaljepa.zip
# ├─ submission.py
# ├─ weights_challenge_1.pt
# └─ weights_challenge_2.pt

from pathlib import Path
import numpy as np
import torch

from braindecode.models import SignalJEPA_Contextual


def resolve_path(name="model_file_name"):
    """Resolve file path in competition environment."""
    if Path(f"/app/input/res/{name}").exists():
        return f"/app/input/res/{name}"
    elif Path(f"/app/input/{name}").exists():
        return f"/app/input/{name}"
    elif Path(f"{name}").exists():
        return f"{name}"
    elif Path(__file__).parent.joinpath(f"{name}").exists():
        return str(Path(__file__).parent.joinpath(f"{name}"))
    else:
        raise FileNotFoundError(
            f"Could not find {name} in /app/input/res/ or /app/input/ or current directory"
        )


def get_hbn_chs_info():
    """Get hardcoded 129-channel HBN electrode locations.

    Returns MNE-compatible channel info for GSN-HydroCel-129 montage.
    Coordinates are embedded from GSN_HydroCel_129_AdjustedLabels.sfp.

    Returns:
        List of 129 channel info dicts with structure:
            - ch_name: Channel name (str)
            - loc: 12-element array with coordinates at positions [3:6]
            - kind: Channel type (2 = EEG)
            - coil_type: Coil type (1 = EEG)
            - unit: Unit (107 = Volts)
            - coord_frame: Coordinate frame (4 = head)
    """
    # 129 EEG channel names and coordinates from GSN-HydroCel-129 montage
    # Format: (channel_name, X, Y, Z) in cm
    channel_data = [
        ("F10", 5.787677636, 5.520863216, -2.577468644),
        ("AF8", 5.291804727, 6.709097557, 0.307434896),
        ("AF4", 3.864122447, 7.63424051, 3.067770143),
        ("F2", 2.868837559, 7.145708546, 4.989564557),
        ("E5", 1.479340453, 5.68662139, 6.812878187),
        ("FCz", 0, 3.806770224, 7.891304964),
        ("E7", -1.223800252, 1.558864431, 8.44043914),
        ("E8", 4.221901505, 7.998817387, -1.354789681),
        ("FP2", 2.695405558, 8.884820317, 1.088308144),
        ("E10", 1.830882336, 8.708839134, 3.18709115),
        ("Fz", 0, 7.96264703, 5.044718001),
        ("E12", -1.479340453, 5.68662139, 6.812878187),
        ("FC1", -2.435870762, 3.254307219, 7.608766206),
        ("E14", 1.270447661, 9.479016328, -0.947183306),
        ("E15", 0, 9.087440894, 1.333345013),
        ("AFz", 0, 9.076490798, 3.105438474),
        ("E17", 0, 9.271139705, -2.211516434),
        ("E18", -1.830882336, 8.708839134, 3.18709115),
        ("F1", -2.868837559, 7.145708546, 4.989564557),
        ("E20", -3.825797111, 5.121648995, 5.942844877),
        ("E21", -1.270447661, 9.479016328, -0.947183306),
        ("FP1", -2.695405558, 8.884820317, 1.088308144),
        ("AF3", -3.864122447, 7.63424051, 3.067770143),
        ("F3", -4.459387187, 6.021159964, 4.365321482),
        ("E25", -4.221901505, 7.998817387, -1.354789681),
        ("AF7", -5.291804727, 6.709097557, 0.307434896),
        ("F5", -5.682547954, 5.453384344, 2.836565436),
        ("FC5", -5.546670402, 4.157847823, 4.627615703),
        ("FC3", -4.762196763, 2.697832099, 6.297663028),
        ("C1", -3.695490968, 0.960411022, 7.627828134),
        ("E31", -1.955187826, -0.684381878, 8.564858511),
        ("F9", -5.787677636, 5.520863216, -2.577468644),
        ("E33", -6.399087198, 4.127248875, -0.356852241),
        ("FT7", -6.823959684, 2.968422112, 2.430080351),
        ("E35", -6.414469893, 1.490027747, 4.741794544),
        ("C3", -5.47913021, 0.284948655, 6.38332782),
        ("CP1", -3.909902609, -1.519049882, 7.764134929),
        ("FT9", -6.550732888, 3.611543152, -3.353155926),
        ("E39", -7.191620108, 0.850096251, -0.882936903),
        ("E40", -7.391919265, 0.032151584, 2.143634599),
        ("C5", -6.905051715, -0.800953972, 4.600056501),
        ("CP3", -5.956055073, -2.338984312, 6.00361353),
        ("E43", -6.518995129, 2.417299399, -5.253637073),
        ("T9", -6.840717711, 1.278489412, -3.5553823),
        ("T11", -7.304625099, -1.866238006, -0.629182006),
        ("TP7", -7.312517928, -2.298574078, 2.385298838),
        ("CP5", -6.737313764, -3.011819533, 4.178390203),
        ("E48", -5.934584124, 2.22697797, -7.934360742),
        ("E49", -6.298127313, 0.41663451, -6.069156425),
        ("E50", -6.78248072, -4.023512045, -0.232191092),
        ("P5", -6.558030032, -4.667036048, 2.749989597),
        ("P3", -5.831241498, -4.494821698, 4.955347697),
        ("E53", -4.193518856, -4.037020083, 6.982920038),
        ("E54", -2.270752074, -3.414835627, 8.204556551),
        ("CPz", 0, -2.138343513, 8.791875902),
        ("E56", -6.174969392, -2.458138877, -5.637380998),
        ("TP9", -6.580438308, -3.739554155, -2.991084431),
        ("E58", -6.034746843, -5.755782196, 0.051843011),
        ("E59", -5.204501802, -6.437833018, 2.984444293),
        ("P1", -4.116929504, -6.061561438, 5.365757296),
        ("E61", -2.344914884, -5.481057427, 7.057748614),
        ("Pz", 0, -6.676694032, 6.465208258),
        ("E63", -5.333266171, -4.302240169, -5.613509789),
        ("P9", -5.404091392, -5.870302681, -2.891640039),
        ("PO7", -4.645302298, -7.280552408, 0.130139701),
        ("E66", -3.608293164, -7.665487704, 3.129931648),
        ("PO3", -1.844644417, -7.354417376, 5.224001733),
        ("E68", -3.784983913, -6.401014415, -5.260040689),
        ("E69", -3.528848027, -7.603010836, -2.818037873),
        ("O1", -2.738838019, -8.607966849, 0.239368223),
        ("E71", -1.404967401, -8.437486994, 3.277284901),
        ("Plz", 0, -7.829896826, 4.687622229),
        ("E73", -1.929652202, -7.497197868, -5.136777648),
        ("E74", -1.125731192, -8.455208629, -2.632832329),
        ("Oz", 0, -8.996686498, 0.487952047),
        ("E76", 1.404967401, -8.437486994, 3.277284901),
        ("PO4", 1.844644417, -7.354417376, 5.224001733),
        ("E78", 2.344914884, -5.481057427, 7.057748614),
        ("E79", 2.270752074, -3.414835627, 8.204556551),
        ("E80", 1.955187826, -0.684381878, 8.564858511),
        ("E81", 0, -7.85891896, -4.945387489),
        ("E82", 1.125731192, -8.455208629, -2.632832329),
        ("O2", 2.738838019, -8.607966849, 0.239368223),
        ("E84", 3.608293164, -7.665487704, 3.129931648),
        ("P2", 4.116929504, -6.061561438, 5.365757296),
        ("E86", 4.193518856, -4.037020083, 6.982920038),
        ("CP2", 3.909902609, -1.519049882, 7.764134929),
        ("E88", 1.929652202, -7.497197868, -5.136777648),
        ("E89", 3.528848027, -7.603010836, -2.818037873),
        ("PO8", 4.645302298, -7.280552408, 0.130139701),
        ("E91", 5.204501802, -6.437833018, 2.984444293),
        ("P4", 5.831241498, -4.494821698, 4.955347697),
        ("CP4", 5.956055073, -2.338984312, 6.00361353),
        ("E94", 3.784983913, -6.401014415, -5.260040689),
        ("P10", 5.404091392, -5.870302681, -2.891640039),
        ("E96", 6.034746843, -5.755782196, 0.051843011),
        ("P6", 6.558030032, -4.667036048, 2.749989597),
        ("CP6", 6.737313764, -3.011819533, 4.178390203),
        ("E99", 5.333266171, -4.302240169, -5.613509789),
        ("TP10", 6.580438308, -3.739554155, -2.991084431),
        ("E101", 6.78248072, -4.023512045, -0.232191092),
        ("TP8", 7.312517928, -2.298574078, 2.385298838),
        ("C6", 6.905051715, -0.800953972, 4.600056501),
        ("C4", 5.47913021, 0.284948655, 6.38332782),
        ("C2", 3.695490968, 0.960411022, 7.627828134),
        ("E106", 1.223800252, 1.558864431, 8.44043914),
        ("E107", 6.174969392, -2.458138877, -5.637380998),
        ("T12", 7.304625099, -1.866238006, -0.629182006),
        ("E109", 7.391919265, 0.032151584, 2.143634599),
        ("E110", 6.414469893, 1.490027747, 4.741794544),
        ("FC4", 4.762196763, 2.697832099, 6.297663028),
        ("FC2", 2.435870762, 3.254307219, 7.608766206),
        ("E113", 6.298127313, 0.41663451, -6.069156425),
        ("T10", 6.840717711, 1.278489412, -3.5553823),
        ("E115", 7.191620108, 0.850096251, -0.882936903),
        ("FT8", 6.823959684, 2.968422112, 2.430080351),
        ("FC6", 5.546670402, 4.157847823, 4.627615703),
        ("E118", 3.825797111, 5.121648995, 5.942844877),
        ("E119", 5.934584124, 2.22697797, -7.934360742),
        ("E120", 6.518995129, 2.417299399, -5.253637073),
        ("FT10", 6.550732888, 3.611543152, -3.353155926),
        ("F8", 6.399087198, 4.127248875, -0.356852241),
        ("F6", 5.682547954, 5.453384344, 2.836565436),
        ("E124", 4.459387187, 6.021159964, 4.365321482),
        ("E125", 6.118458137, 4.523870113, -4.409174427),
        ("E126", 3.743504949, 6.649204911, -6.530243068),
        ("E127", -3.743504949, 6.649204911, -6.530243068),
        ("E128", -6.118458137, 4.523870113, -4.409174427),
        ("Cz", 0, 0, 8.899186843),
    ]

    # Create MNE-compatible channel info structure
    chs_info = []
    for ch_name, x, y, z in channel_data:
        # Create 12-element location array with coordinates at positions [3:6]
        # (MNE stores at [0:3], but braindecode SignalJEPA expects at [3:6])
        loc = np.zeros(12, dtype=np.float64)
        loc[3:6] = [x, y, z]

        ch_info = {
            'ch_name': ch_name,
            'loc': loc,
            'kind': 2,          # FIFFV_EEG_CH
            'coil_type': 1,     # FIFFV_COIL_EEG
            'unit': 107,        # FIFF_UNIT_V
            'coord_frame': 4,   # FIFFV_COORD_HEAD
        }
        chs_info.append(ch_info)

    return chs_info


class Submission:
    def __init__(self, SFREQ, DEVICE):
        self.sfreq = SFREQ
        self.device = DEVICE

    def get_model_challenge_1(self):
        """Load SignalJEPA_Contextual model for Challenge 1 (response time prediction).

        Returns:
            Finetuned SignalJEPA_Contextual model in eval mode
        """
        # Load electrode locations
        chs_info = get_hbn_chs_info()

        # Create SignalJEPA_Contextual model directly
        model = SignalJEPA_Contextual(
            n_outputs=1,  # Regression: response time
            n_chans=129,
            n_times=200,
            sfreq=self.sfreq,
            input_window_seconds=2.0,
            chs_info=chs_info,
            n_spat_filters=4,
            transformer__d_model=64,
            transformer__num_encoder_layers=12,
            transformer__nhead=8,
            drop_prob=0.1
        ).to(self.device)

        # Load finetuned checkpoint
        checkpoint = torch.load(
            resolve_path("weights_challenge_1.pt"),
            map_location=self.device,
            weights_only=False
        )

        # Load model weights
        model.load_state_dict(checkpoint['model_state_dict'])
        model.eval()

        return model

    def get_model_challenge_2(self):
        """Load SignalJEPA_Contextual model for Challenge 2 (externalizing factor prediction).

        Returns:
            Finetuned SignalJEPA_Contextual model in eval mode
        """
        # Load electrode locations
        chs_info = get_hbn_chs_info()

        # Create SignalJEPA_Contextual model directly
        model = SignalJEPA_Contextual(
            n_outputs=1,  # Regression: externalizing factor
            n_chans=129,
            n_times=200,
            sfreq=self.sfreq,
            input_window_seconds=2.0,
            chs_info=chs_info,
            n_spat_filters=4,
            transformer__d_model=64,
            transformer__num_encoder_layers=12,
            transformer__nhead=8,
            drop_prob=0.1
        ).to(self.device)

        # Load finetuned checkpoint
        checkpoint = torch.load(
            resolve_path("weights_challenge_2.pt"),
            map_location=self.device,
            weights_only=False
        )

        # Load model weights
        model.load_state_dict(checkpoint['model_state_dict'])
        model.eval()

        return model


# ##########################################################################
# # How Submission class will be used
# # ---------------------------------
# from submission import Submission
#
# SFREQ = 100
# DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# sub = Submission(SFREQ, DEVICE)
# model_1 = sub.get_model_challenge_1()
# model_1.eval()

# warmup_loader_challenge_1 = DataLoader(HBN_R5_dataset1, batch_size=BATCH_SIZE)
# final_loader_challenge_1 = DataLoader(secret_dataset1, batch_size=BATCH_SIZE)

# with torch.inference_mode():
#     for batch in warmup_loader_challenge_1:  # and final_loader later
#         X, y, infos = batch
#         X = X.to(dtype=torch.float32, device=DEVICE)
#         # X.shape is (BATCH_SIZE, 129, 200)

#         # Forward pass
#         y_pred = model_1.forward(X)
#         # save prediction for computing evaluation score
#         ...
# score1 = compute_score_challenge_1(y_true, y_preds)
# del model_1
# gc.collect()

# model_2 = sub.get_model_challenge_2()
# model_2.eval()

# warmup_loader_challenge_2 = DataLoader(HBN_R5_dataset2, batch_size=BATCH_SIZE)
# final_loader_challenge_2 = DataLoader(secret_dataset2, batch_size=BATCH_SIZE)

# with torch.inference_mode():
#     for batch in warmup_loader_challenge_2:  # and final_loader later
#         X, y, crop_inds, infos = batch
#         X = X.to(dtype=torch.float32, device=DEVICE)
#         # X shape is (BATCH_SIZE, 129, 200)

#         # Forward pass
#         y_pred = model_2.forward(X)
#         # save prediction for computing evaluation score
#         ...
# score2 = compute_score_challenge_2(y_true, y_preds)
# overall_score = compute_leaderboard_score(score1, score2)
